<!DOCTYPE html>
<?php
    session_start();
    include_once 'connect.php';
?>
<html>
    <head>
        <title>sample</title>
    </head>
    <?php
        if(isset($_POST['submitform'])) {
            /*require 'sample.php'; this contains the functions*/
            $sql = "INSERT INTO table1 (title) VALUES ('".$_POST['title']."')";
            $conn->query($sql);
        }
    ?>
    <body>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $sql = "SELECT * FROM table1";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>
                            <td>'.$row['id'].'</td>
                            <td>'.$row['title'].'</td>
                        </tr>';
                        
                    }
                ?>
            </tbody>
        </table>
        <form action="index.php" method="POST">
            <input type="text" name="title">
            <button type="submit" name="submitform" >Submit</button>
        </form>
    </body>
</html>